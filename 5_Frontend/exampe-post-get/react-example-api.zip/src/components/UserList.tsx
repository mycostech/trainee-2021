import React, { useEffect } from "react"
import useUserApi from "../hooks/useUserApi"
import Loading from "./Loading"
import UserDetail from "./UserDetail/UserDetail"

function UserList() {

    const [users, loading, getAllUser] = useUserApi()

    useEffect(() => {
        getAllUser()

    }, [getAllUser])

    return (
        <div>
            {loading ? <Loading /> :
                users.map(m => {
                    return <UserDetail user={m} key={m.id} />
                })
            }
        </div>
    )

}

export default UserList