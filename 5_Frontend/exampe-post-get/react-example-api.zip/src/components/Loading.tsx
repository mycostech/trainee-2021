function Loading() {


    return (
        <div style={{
            width: 200
        }}>
            Loading...
        </div>
    )
}

export default Loading