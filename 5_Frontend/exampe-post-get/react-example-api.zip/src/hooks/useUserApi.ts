import { useCallback, useState } from "react"
import userApi from "../api/userAPI"
import User from "../models/User"

const useUserApi = () => {
 
    const [users, setUsers] = useState<User[]>([])
    const [loading, setLoading] = useState<boolean>(false)

    const getAllUsers = useCallback(
        async () => {
            setLoading(true)
            const result = await userApi.getUsers()
            setUsers(result.data)
            setLoading(false)
        },
        [setLoading, setUsers],
    )

    return [
        users,
        loading,
        getAllUsers
    ] as const
}


export default useUserApi