interface UserAddress {
    street: string
    suite: string
    city: string
    zipcode: string
}

export default UserAddress