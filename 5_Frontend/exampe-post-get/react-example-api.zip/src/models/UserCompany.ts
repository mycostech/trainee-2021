interface UserCompany {
    name: string
    catchPhrase: string
    bs: string
}

export default UserCompany